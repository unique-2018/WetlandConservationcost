library(testthat)
library(triangle)

test_check("triangle")
