UUIDgenerate <- function(use.time = NA, n = 1L) .Call(UUID_gen, use.time, n)
