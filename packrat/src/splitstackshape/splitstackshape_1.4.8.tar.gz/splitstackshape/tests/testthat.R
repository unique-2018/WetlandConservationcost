library(testthat)
library(splitstackshape)

test_check("splitstackshape")
